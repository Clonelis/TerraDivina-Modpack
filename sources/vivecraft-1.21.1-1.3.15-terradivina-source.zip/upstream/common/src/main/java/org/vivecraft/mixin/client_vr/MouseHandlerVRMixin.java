package org.vivecraft.mixin.client_vr;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.vivecraft.client_vr.ClientDataHolderVR;
import org.vivecraft.client_vr.VRData;
import org.vivecraft.client_vr.VRState;
import org.vivecraft.client_vr.extensions.WindowExtension;
import org.vivecraft.client_vr.gameplay.screenhandlers.GuiHandler;
import org.vivecraft.common.utils.MathUtils;

@Mixin(MouseHandler.class)
public class MouseHandlerVRMixin {

    @Shadow
    private boolean mouseGrabbed;
    @Final
    @Shadow
    private Minecraft minecraft;

    @Shadow
    private double accumulatedDX;

    @Shadow
    private double accumulatedDY;

    @Unique
    private Vector3f vivecraft$lastAim;

    @Inject(method = "handleAccumulatedMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MouseHandler;isMouseGrabbed()Z"))
    private void vivecraft$modifyMouseTravel(CallbackInfo ci) {
        if (VRState.VR_RUNNING && this.minecraft.screen == null) {
            VRData.VRDevicePose aim = ClientDataHolderVR.getInstance().vrPlayer.getVRDataWorld().getAim();
            Vector3f dir = aim.getDirection()
                .normalize();
            if (this.vivecraft$lastAim != null) {
                // yaw
                double yaw = 0;
                // no 0 or those angles are invalid
                if (this.vivecraft$lastAim.x != 0 && this.vivecraft$lastAim.z != 0 && dir.x != 0 && dir.z != 0) {
                    yaw = Math.atan2(-this.vivecraft$lastAim.x, this.vivecraft$lastAim.z) - Math.atan2(-dir.x, dir.z);
                    yaw = yaw > Math.PI ? yaw - Math.TAU : (yaw < -Math.PI ? yaw + Math.TAU : yaw);
                }
                this.accumulatedDX = -yaw * Mth.RAD_TO_DEG * 5F;

                // pitch
                Vector3f up = aim.getCustomVector(MathUtils.UP);
                double pitch = (Math.asin(this.vivecraft$lastAim.y) - Math.asin(dir.y)) * (up.y < 0 ? -1 : 1);
                this.accumulatedDY = pitch * Mth.RAD_TO_DEG * 5F;
            }
            this.vivecraft$lastAim = dir;
        } else {
            this.vivecraft$lastAim = null;
        }
    }

    @WrapOperation(method = "onPress", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;isSpectator()Z"))
    private boolean vivecraft$checkNull(LocalPlayer instance, Operation<Boolean> original) {
        return instance != null && original.call(instance);
    }

    @WrapWithCondition(method = "turnPlayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;turn(DD)V"))
    private boolean vivecraft$noTurning(LocalPlayer instance, double x, double y) {
        return !VRState.VR_RUNNING;
    }

    @Inject(method = "grabMouse", at = @At("HEAD"), cancellable = true)
    private void vivecraft$noMouseGrab(CallbackInfo ci) {
        if (!VRState.VR_RUNNING) {
            return;
        }

        if (!ClientDataHolderVR.getInstance().vrSettings.seated) {
            this.mouseGrabbed = true;
            ci.cancel();
        }
    }

    @Inject(method = "releaseMouse", at = @At(value = "HEAD"), cancellable = true)
    private void vivecraft$noMouseReleaseMovement(CallbackInfo ci) {
        if (!VRState.VR_RUNNING) {
            return;
        }

        if (!ClientDataHolderVR.getInstance().vrSettings.seated) {
            this.mouseGrabbed = false;
            ci.cancel();
        }
    }

    // we change the screen size different from window size, so need to modify the mouse position on grab/release
    @ModifyArg(method = {"grabMouse", "releaseMouse"}, at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/platform/InputConstants;grabOrReleaseMouse(JIDD)V"), index = 2)
    private double vivecraft$modifyXCenter(double x) {
        return VRState.VR_RUNNING
            ? (double) ((WindowExtension) (Object) this.minecraft.getWindow()).vivecraft$getActualScreenWidth() / 2
            : x;
    }

    @ModifyArg(method = {"grabMouse", "releaseMouse"}, at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/platform/InputConstants;grabOrReleaseMouse(JIDD)V"), index = 3)
    private double vivecraft$modifyYCenter(double y) {
        return VRState.VR_RUNNING
            ? (double) ((WindowExtension) (Object) this.minecraft.getWindow()).vivecraft$getActualScreenHeight() / 2
            : y;
    }

    // we change the screen size different from window size, so adapt move events to the emulated size
    @ModifyVariable(method = "onMove", at = @At(value = "HEAD"), ordinal = 0, argsOnly = true)
    private double vivecraft$modifyX(double x) {
        if (VRState.VR_RUNNING) {
            x *= GuiHandler.GUI_WIDTH /
                (double) ((WindowExtension) (Object) this.minecraft.getWindow()).vivecraft$getActualScreenWidth();
        }
        return x;
    }

    @ModifyVariable(method = "onMove", at = @At(value = "HEAD"), ordinal = 1, argsOnly = true)
    private double vivecraft$modifyY(double y) {
        if (VRState.VR_RUNNING) {
            y *= (double) GuiHandler.GUI_HEIGHT /
                (double) ((WindowExtension) (Object) this.minecraft.getWindow()).vivecraft$getActualScreenHeight();
        }
        return y;
    }
}
