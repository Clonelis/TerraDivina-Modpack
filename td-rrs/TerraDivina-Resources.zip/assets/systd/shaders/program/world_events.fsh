#version 150
uniform sampler2D DiffuseSampler;
uniform float Event;
uniform float Intensity;
uniform float Danger;
uniform float Clock;
in vec2 texCoord;
out vec4 fragColor;
void main() {
    vec2 uv = texCoord;
    float edge = smoothstep(0.18, 0.68, length(uv - 0.5));
    if (Event > 4.5 && Event < 5.5) {
        float wave = sin(uv.y * 41.0 + Clock * 1.7) * sin(uv.x * 17.0 - Clock * 0.8);
        float distant = smoothstep(0.12,0.45,uv.y) * (1.0-smoothstep(0.72,1.0,uv.y));
        uv.x += wave * 0.0025 * Intensity * distant;
        uv.y += sin(uv.x * 35.0 + Clock * 1.4) * 0.0011 * Intensity * distant;
    } else if (Event < 1.5) {
        uv += vec2(sin(uv.y * 12.0 + Clock * 1.1), cos(uv.x * 9.0 + Clock * 0.7)) * 0.002 * Intensity * edge;
    }
    vec4 color = texture(DiffuseSampler, clamp(uv, vec2(0.002), vec2(0.998)));
    if (Event > 2.5 && Event < 3.5) {
        float gray = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));
        color.rgb = mix(color.rgb, vec3(gray), Intensity) * 0.90;
        float heartbeat = pow(max(0.0, sin(Clock * (4.0 + Danger))), 10.0);
        color.rgb *= 1.0 - edge * Danger * (0.055 + heartbeat * 0.035);
    } else if (Event > 4.5 && Event < 5.5) {
        color.rgb = mix(color.rgb, color.rgb * vec3(1.06, 1.015, 0.94), Intensity * 0.45);
    }
    fragColor = vec4(color.rgb, 1.0);
}
